function validateForm() {
	if (validateUsername()) {
		return true;
	}else {
	return false;
	}
}
function validateUsername () {
	var field = $('#name').val();
	var filter = /^.{6,}$/;
	if(filter.test(field) == false) {
		$('#name').parent().parent().addClass('has-error');
		$('#name').next().css("color", "red").html('Chua nhap');
		return false;
	}else {
		$('#name').parent().parent().removeClass('has-error');
		$('#name').next().html('');
	return true;
	}

}