<?php
class Db{
	//Tao bien $conn ket noi
	public static $conn;
	//Tao ket noi trong ham construct
	public function __construct(){
		self::$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
		self::$conn->set_charset('utf8');
	}
	public function __destruct(){
		self::$conn->close();
	}
	public function getData($obj){
		$arr = array();
		while($row = $obj->fetch_assoc()){
			$arr[]=$row;
		}
		return $arr;
	}
	//Viet ham lay ra tên và giá sản phẩm của hãng “Apple”
	public function product2(){
		//Viet cau SQL
		if(isset($_GET['key']))
		{
			$key = $_GET['key'];
		}
		$sql = "SELECT * FROM `products` JOIN `manufactures` ON `products`.`manu_id` = `manufactures`.`manu_ID` JOIN `protypes` ON `products`.`type_id` = `protypes`.`type_id` WHERE Name LIKE '%".$key."%'";
		//Thuc thi cau truy van

		$result = self::$conn->query($sql);
		return $this->getData($result);

	}
	public function product1(){
		//Viet cau SQL
		$sql = "SELECT * FROM `products` JOIN `manufactures` ON `products`.`manu_id` = `manufactures`.`manu_ID` JOIN `protypes` ON `products`.`type_id` = `protypes`.`type_id`";
		//Thuc thi cau truy van
		$result = self::$conn->query($sql);
		return $this->getData($result);
	}

	public function getAllProducts($page, $per_page)
	{
		$first_link = ($page - 1) * $per_page; 
		$sql = "SELECT * FROM `products` JOIN `manufactures` ON `products`.`manu_id` = `manufactures`.`manu_ID` JOIN `protypes` ON `products`.`type_id` = `protypes`.`type_id` LIMIT  $first_link, $per_page"; 
		$result = self::$conn->query($sql);
		return $this->getData($result);
	} 

	public function paginate1($key,$url, $total, $page, $per_page)
	{
		$total_links = ceil($total/$per_page);

		$link =""; 

		for($j=1; $j <= $total_links ; $j++) 
		{
			$link = $link."<a href='$url?key=".$key."page=$j'>$j    </a>";
		} 
		return $link; 
	}

	public function paginate($url, $total, $page, $per_page)
	{
		$total_links = ceil($total/$per_page);

		$link =""; 

		for($j=1; $j <= $total_links ; $j++) 
		{
			$link = $link."<a href='$url?page=$j'>$j    </a>";
		} 
		return $link; 
	}
	public function product3($name,$type_id, $manu_id, $description, $price){
		if(isset($_POST['name']))
		{
			$name = $_POST['name'];
			$image = $_FILES["fileToUpload"]["name"];
			$type_id = $_POST['type_id'];	
			$manu_id = $_POST['manu_id'];	
			$description = $_POST['description'];	
			$price = $_POST['price'];
		}
		$sql = "INSERT INTO products (Name,image,description,Price,manu_id,type_id)
    			VALUES ('$name','$image', '$description', $price,$manu_id,$type_id)";
   		$result = self::$conn->query($sql);
		return $result;

	}
	public function delete($ID)
	{
		$sql = "DELETE FROM `products` WHERE ID = $ID";
		self::$conn->query($sql);
	}
	public function edit($ID){

		if(isset($_GET['ID'])){
			$ID = $_GET['ID'];
		}
		$sql     = "SELECT * FROM `products` JOIN `manufactures` ON `products`.`manu_id` = `manufactures`.`manu_ID` JOIN `protypes` ON `products`.`type_id` = `protypes`.`type_id` WHERE ID='$ID'";
		$result = self::$conn->query($sql);
		return $this->getData($result);
	}
	public function login($user, $pass){
		//viet cau SQL
		$sql = "SELECT * FROM `login`";
		//thuc thi cau truy van
		$result = self::$conn->query($sql);
		$User = $this->getData($result);
		foreach ($User as $value) {
			if ($value["User"] == $user && $pass == $value["Pass"]){
				return true;
			}
		}
		return false;
	}
	public function upload($name,$image,$description,$price,$manu_id,$type_id){
		$name = $_POST['name'];
		$type_id = $_POST['type_id'];	
		$manu_id = $_POST['manu_id'];
		$image = $_FILES["fileToUpload"]["name"];	
		$description = $_POST['description'];	
		$price = $_POST['price'];
		$sql = "UPDATE products SET Name ='$name', image = '$image', description = '$description' , Price = '$price' , manu_id = '$manu_id' , type_id = '$type_id'  WHERE ID = 1";
		$result = self::$conn->query($sql);
		var_dump($sql);
		return $result;
	}

}

