<?php
	require "config.php";
	require "db.php";
	if(isset($_POST['name']))
		{
			$name = $_POST['name'];	
			$type_id = $_POST['type_id'];	
			$manu_id = $_POST['manu_id'];	
			$description = $_POST['description'];	
			$price = $_POST['price'];
		
	$db = new Db;
	echo $db->product3($name,$type_id, $manu_id, $description, $price);
	$targetDir = "image/";
	$targetFile = $targetDir.basename($_FILES["fileToUpload"]["name"]);
	$uploadOK = 1;
	$imageFileType = pathinfo($targetFile,PATHINFO_EXTENSION);
		move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],"image/".$_FILES["fileToUpload"]["name"]);
		if (isset($_POST["submit"])) {
			$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			if ($check !== false) {
				echo "File is an image".check["mine"].".";
				$uploadOK = 1;
			}else{
				echo "File is not an image";
				$uploadOK = 0;
			}
		}

	}else
	{
	header('location:index.php');
	}

	header('location:index.php');

?>