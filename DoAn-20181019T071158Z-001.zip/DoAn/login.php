<?php
session_start();
require "config.php";
require "db.php";
if(isset($_GET['user'])){
	$user = $_GET['user'];
	$pass = $_GET['pass'];
	$db = new db();
	if($db->login($user,$pass)){
		if(isset($_GET['remember'])){
			setcookie('user',$_GET['user'],time()+3600);
			setcookie('pass',$_GET['pass'],time()+3600);
		}
		else{
			setcookie('user',$_GET['user'],time()-3600);
			setcookie('pass',$_GET['pass'],time()-3600);
		}
		//echo "Logged in successfully";
		//Luu thong tin vao session
		$_SESSION['user']=$_GET['user'];
		header('location:index.php');
	}else{
		echo "ko oc";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		body{
			background-image: url(../DoAn/hinhlogin3.jpg);
            padding:60px;
            font-size:20px;
            background-size: cover;
            text-align: center;
            color: white;
		}
		.login:hover{
			background : lightgreen;
		}
	</style>
</head>
<body>
<form action="" method="get">
	<h2>LOGIN</h2>
	Username  <input type="text" name="user" value="<?php echo isset($_COOKIE['user'])?$_COOKIE['user']:"" ?>"><br>
	Password  <input type="Password" name="pass"><br>
	<input type="checkbox" name="remember">Remember <br>
	<input class="login" type="submit" name="" value="Đăng Nhập">
</form>
</body>
</html>
